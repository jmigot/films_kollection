<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="en_US">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../sources/MainWindow.cpp" line="68"/>
        <source>Searching update...</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../sources/MainWindow.cpp" line="76"/>
        <source>A newer version is available !</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../sources/MainWindow.cpp" line="82"/>
        <source>Your already have the latest version.</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../sources/MainWindow.cpp" line="90"/>
        <source>Impossible to get latest version number.</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../sources/MainWindow.cpp" line="98"/>
        <source>Updating...</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../sources/MainWindow.cpp" line="109"/>
        <source>Error</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../sources/MainWindow.cpp" line="109"/>
        <source>We are sorry, automatic update doesn&apos;t exist for your system.</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../sources/MainWindow.cpp" line="133"/>
        <source>Downloading %1...</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../sources/MainWindow.cpp" line="172"/>
        <source>Update done !</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../sources/MainWindow.cpp" line="179"/>
        <source>An error occured while downloading file(s).</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../sources/MainWindow.cpp" line="187"/>
        <source>Impossible to download files list.</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../sources/Network.cpp" line="65"/>
        <source>Mozilla (en) Gecko/Firefox</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../../sources/Network.cpp" line="107"/>
        <source>Timeout</source>
        <translation></translation>
    </message>
</context>
</TS>
