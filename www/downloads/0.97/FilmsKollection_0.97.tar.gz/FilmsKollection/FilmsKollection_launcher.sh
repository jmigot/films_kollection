#!/bin/bash
export LD_LIBRARY_PATH=./
chmod +x FilmsKollection
./FilmsKollection
